import React, { useEffect, useMemo, useState } from 'react';
import { questions } from './data/questions';
import {
  EXAM_DURATION_MINUTES,
  QUESTIONS_PER_LEVEL,
  calculateResult,
  formatTime,
  shuffle,
  validateQuestions,
} from './utils';

const STORAGE_KEY = 'ap-tet-urdu-mock-attempt';

function createAttempt() {
  const randomized = shuffle(questions);
  return {
    level1Questions: randomized.slice(0, QUESTIONS_PER_LEVEL),
    level2Questions: randomized.slice(QUESTIONS_PER_LEVEL),
    currentLevel: 1,
    currentQuestionIndex: 0,
    answers: {},
    started: true,
    completed: false,
    secondsRemaining: EXAM_DURATION_MINUTES * 60,
  };
}

function App() {
  const [attempt, setAttempt] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [screen, setScreen] = useState(() => (attempt?.started ? 'exam' : 'home'));
  const [review, setReview] = useState(false);
  const [levelResult, setLevelResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    try {
      validateQuestions(questions);
    } catch (validationError) {
      setError(validationError.message);
    }
  }, []);

  useEffect(() => {
    if (attempt?.started && !attempt.completed) localStorage.setItem(STORAGE_KEY, JSON.stringify(attempt));
  }, [attempt]);

  useEffect(() => {
    if (!attempt?.started || attempt.completed || screen !== 'exam') return undefined;
    const timer = window.setInterval(() => {
      setAttempt((current) => {
        if (!current || current.secondsRemaining <= 1) return { ...current, secondsRemaining: 0 };
        return { ...current, secondsRemaining: current.secondsRemaining - 1 };
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [attempt?.started, attempt?.completed, screen]);

  useEffect(() => {
    if (attempt?.secondsRemaining === 0 && screen === 'exam') submitLevel(true);
  }, [attempt?.secondsRemaining, screen]);

  const currentQuestions = attempt?.currentLevel === 1 ? attempt.level1Questions : attempt?.level2Questions;
  const currentQuestion = currentQuestions?.[attempt.currentQuestionIndex];
  const currentResult = useMemo(
    () => (attempt && currentQuestions ? calculateResult(currentQuestions, attempt.answers) : null),
    [attempt, currentQuestions],
  );

  function startExam() {
    const next = createAttempt();
    setAttempt(next);
    setLevelResult(null);
    setReview(false);
    setScreen('exam');
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }

  function updateAttempt(changes) {
    setAttempt((current) => ({ ...current, ...changes }));
  }

  function selectAnswer(answer) {
    updateAttempt({ answers: { ...attempt.answers, [currentQuestion.id]: answer } });
  }

  function submitLevel(autoSubmitted = false) {
    if (!attempt || !currentQuestions) return;
    if (!autoSubmitted && !window.confirm(`آپ نے ${currentResult.answered} میں سے ${currentQuestions.length} سوالات کے جواب دیے ہیں۔ کیا آپ جمع کرنا چاہتے ہیں؟`)) return;
    const result = calculateResult(currentQuestions, attempt.answers);
    setLevelResult(result);
    setScreen(attempt.currentLevel === 1 ? 'level-result' : 'final-result');
    updateAttempt({ completed: attempt.currentLevel === 2 });
  }

  function proceedToLevelTwo() {
    updateAttempt({ currentLevel: 2, currentQuestionIndex: 0 });
    setLevelResult(null);
    setScreen('exam');
  }

  function restart() {
    if (!window.confirm('کیا آپ موجودہ کوشش ختم کرکے نیا ٹیسٹ شروع کرنا چاہتے ہیں؟')) return;
    localStorage.removeItem(STORAGE_KEY);
    startExam();
  }

  if (error) return <main className="shell"><div className="error" role="alert">{error}</div></main>;
  if (screen === 'home') return <Home onStart={startExam} hasSavedAttempt={Boolean(attempt?.started)} onResume={() => setScreen('exam')} />;
  if (screen === 'exam' && currentQuestion) {
    return (
      <Exam
        attempt={attempt}
        question={currentQuestion}
        questions={currentQuestions}
        result={currentResult}
        onAnswer={selectAnswer}
        onNavigate={(index) => updateAttempt({ currentQuestionIndex: index })}
        onSubmit={() => submitLevel(false)}
        onRestart={restart}
      />
    );
  }
  if (screen === 'level-result') {
    return <Result title="LEVEL 1 RESULT" result={levelResult} onNext={proceedToLevelTwo} nextLabel="PROCEED TO LEVEL 2" />;
  }
  if (screen === 'final-result') {
    const level1 = calculateResult(attempt.level1Questions, attempt.answers);
    const level2 = calculateResult(attempt.level2Questions, attempt.answers);
    return (
      <Result
        title="FINAL RESULT"
        result={{ correct: level1.correct + level2.correct, wrong: level1.wrong + level2.wrong, unanswered: level1.unanswered + level2.unanswered, score: level1.score + level2.score, total: 90, percentage: ((level1.score + level2.score) / 90) * 100 }}
        breakdown={[level1, level2]}
        onNext={() => { setReview(true); setScreen('review'); }}
        nextLabel="REVIEW ANSWERS"
      />
    );
  }
  if (screen === 'review' || review) {
    return <Review attempt={attempt} onBack={() => setScreen('final-result')} onRestart={restart} />;
  }
  return null;
}

function Home({ onStart, hasSavedAttempt, onResume }) {
  return (
    <main className="shell home">
      <section className="hero card">
        <p className="eyebrow">AP TET</p>
        <h1>PRACTICE MOCK TEST</h1>
        <p className="subject">Language 1A – Urdu</p>
        <div className="stats">
          <span><strong>90</strong> سوالات</span><span><strong>2</strong> Levels</span><span><strong>45</strong> ہر Level میں</span>
        </div>
        <p className="instruction">ہر Level میں 45 سوالات ہیں۔ تمام 90 سوالات ایک ہی کوشش میں، بغیر تکرار کے شامل ہوں گے۔</p>
        <button className="primary large" onClick={onStart}>START MOCK TEST</button>
        {hasSavedAttempt && <button className="text-button" onClick={onResume}>محفوظ کوشش جاری رکھیں</button>}
      </section>
    </main>
  );
}

function Exam({ attempt, question, questions: questionSet, result, onAnswer, onNavigate, onSubmit, onRestart }) {
  const index = attempt.currentQuestionIndex;
  const selected = attempt.answers[question.id];
  const isLast = index === questionSet.length - 1;
  return (
    <main className="shell">
      <header className="topbar"><div><strong>AP TET</strong><span> Language 1A – Urdu</span></div><button className="text-button" onClick={onRestart}>Restart Test</button></header>
      <section className="exam-layout">
        <div className="card question-panel" dir="rtl">
          <div className="exam-heading"><span>LEVEL {attempt.currentLevel}</span><span>سوال {index + 1} / {questionSet.length}</span><span className="timer">Time Remaining: {formatTime(attempt.secondsRemaining)}</span></div>
          <div className="progress"><span style={{ width: `${((index + 1) / questionSet.length) * 100}%` }} /></div>
          <article className="question-copy">{question.question}</article>
          <div className="options" role="radiogroup" aria-label="جواب کے اختیارات">
            {question.options.map((option, optionIndex) => {
              const value = optionIndex + 1;
              return <label className={`option ${selected === value ? 'selected' : ''}`} key={`${question.id}-${optionIndex}`}><input type="radio" name={`question-${question.id}`} checked={selected === value} onChange={() => onAnswer(value)} /><span>{option}</span></label>;
            })}
          </div>
          <div className="actions"><button className="secondary" disabled={index === 0} onClick={() => onNavigate(index - 1)}>Previous</button>{isLast ? <button className="primary" onClick={onSubmit}>Submit Level {attempt.currentLevel}</button> : <button className="primary" onClick={() => onNavigate(index + 1)}>Next</button>}</div>
        </div>
        <Navigator questionSet={questionSet} answers={attempt.answers} currentIndex={index} onNavigate={onNavigate} result={result} />
      </section>
    </main>
  );
}

function Navigator({ questionSet, answers, currentIndex, onNavigate }) {
  return <aside className="card navigator"><h2>سوالات</h2><div className="number-grid">{questionSet.map((question, index) => <button key={question.id} className={`${index === currentIndex ? 'current' : ''} ${answers[question.id] ? 'answered' : ''}`} onClick={() => onNavigate(index)} aria-label={`سوال ${index + 1}`}>{index + 1}</button>)}</div><div className="legend"><span className="current-key">Current</span><span className="answered-key">Answered</span><span>Not answered</span></div></aside>;
}

function Result({ title, result, breakdown, onNext, nextLabel }) {
  const message = result.percentage >= 90 ? 'Excellent' : result.percentage >= 75 ? 'Very Good' : result.percentage >= 60 ? 'Good' : 'Keep Practicing';
  return <main className="shell result-page"><section className="card result-card"><p className="eyebrow">AP TET • URDU</p><h1>{title}</h1>{breakdown && <div className="breakdown">{breakdown.map((item, index) => <div key={index}>Level {index + 1}: <strong>{item.score} / {item.total}</strong></div>)}</div>}<div className="score">{result.score} <small>/ {result.total}</small></div><p className="performance">{message}</p><div className="result-grid"><span>Correct<strong>{result.correct}</strong></span><span>Wrong<strong>{result.wrong}</strong></span><span>Unanswered<strong>{result.unanswered}</strong></span><span>Percentage<strong>{result.percentage.toFixed(2)}%</strong></span></div><button className="primary large" onClick={onNext}>{nextLabel}</button></section></main>;
}

function Review({ attempt, onBack, onRestart }) {
  const allQuestions = [...attempt.level1Questions, ...attempt.level2Questions];
  return <main className="shell"><header className="topbar"><button className="secondary" onClick={onBack}>Back to Result</button><button className="text-button" onClick={onRestart}>Restart Test</button></header><section className="review"><h1>REVIEW ANSWERS</h1>{allQuestions.map((question, index) => { const selected = attempt.answers[question.id]; const correct = selected === question.correctAnswer; return <article className={`card review-card ${selected === undefined ? 'unanswered' : correct ? 'correct' : 'wrong'}`} key={question.id}><div className="review-number">سوال {index + 1}</div><div className="question-copy">{question.question}</div><p>آپ کا جواب: <strong>{selected ? question.options[selected - 1] : 'جواب نہیں دیا گیا'}</strong></p><p>درست جواب: <strong>{question.options[question.correctAnswer - 1]}</strong></p><b>{selected === undefined ? 'Not Answered' : correct ? 'Correct' : 'Wrong'}</b></article>; })}</section></main>;
}

export default App;
