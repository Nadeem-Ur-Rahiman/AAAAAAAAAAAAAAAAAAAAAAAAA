export const EXAM_DURATION_MINUTES = 90;
export const QUESTIONS_PER_LEVEL = 45;

export function shuffle(items) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

export function validateQuestions(questions) {
  if (questions.length !== 90) throw new Error('Question bank must contain exactly 90 questions.');
  const ids = questions.map((question) => question.id).sort((a, b) => a - b);
  if (ids.some((id, index) => id !== index + 1)) throw new Error('Question IDs must contain exactly 1 through 90.');
  if (questions.some((question) => question.options.length !== 4)) {
    throw new Error('Every question must contain exactly four options.');
  }
  if (questions.some((question) => ![1, 2, 3, 4].includes(question.correctAnswer))) {
    throw new Error('Every question must have a valid correct answer index.');
  }
  return true;
}

export function calculateResult(questionSet, answers) {
  const correct = questionSet.reduce(
    (total, question) => total + (answers[question.id] === question.correctAnswer ? 1 : 0),
    0,
  );
  const answered = questionSet.filter((question) => answers[question.id] !== undefined).length;
  return {
    correct,
    answered,
    wrong: answered - correct,
    unanswered: questionSet.length - answered,
    score: correct,
    total: questionSet.length,
    percentage: (correct / questionSet.length) * 100,
  };
}

export function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const remainingSeconds = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${remainingSeconds}`;
}
